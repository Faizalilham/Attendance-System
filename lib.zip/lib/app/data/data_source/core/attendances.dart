import 'dart:convert';

class AttendanceRequest {
  String name;
  String date;
  String description;

  AttendanceRequest(
      {required this.name, required this.date, required this.description});

  Map<String, dynamic> toMap() {
    return {"name": name, "date": date, "description": description};
  }

  String toJson() => json.encode(toMap());
}

class AttendanceResponse {
  String message;

  AttendanceResponse(
      {required this.message});

  factory AttendanceResponse.fromMap(Map<String, dynamic> json) {
    return AttendanceResponse(
        message: json["message"]);
  }

}

class StudentTodayResponse {
  String name;
  String date;
  String description;

  StudentTodayResponse(
      {required this.name, required this.date, required this.description});

  factory StudentTodayResponse.fromMap(Map<String, dynamic> json) {
    return StudentTodayResponse(
        name: json["name"],
        date: json["date"],
        description: json["description"]);
  }
}

class Attendances {
  String message;
  List<StudentTodayResponse> data;

  Attendances({required this.message, required this.data});

  factory Attendances.fromMap(Map<String, dynamic> json) {
    return Attendances(
        message: json["message"],
        data: List<StudentTodayResponse>.from((json["data"] as List)
            .map((e) => StudentTodayResponse.fromMap(e))));
  }
}

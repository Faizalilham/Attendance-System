import 'package:attendance_system/app/data/data_source/core/students_response.dart';
import 'package:camera/camera.dart';

import 'package:get/get.dart';

import 'package:sliding_up_panel/sliding_up_panel.dart';

class DetectionsController extends GetxController {
  late List<CameraDescription> cameras;

  RxList<Student> listStudent = <Student>[].obs;

  PanelController panelController = PanelController();

  void toggle() => panelController.isPanelOpen
      ? panelController.close()
      : panelController.open();

  void processDetectedStudent(String student) {
    if(listStudent.any((student) => student.name != student)){
      listStudent.add(Student(
          name: student, nim: "20090086", address: "", images: "", email: ""));
    }
    
  }

  // @override
  // void onInit()async{
  //   a();
  //   cameras = await availableCameras();
  //   super.onInit();
  // }

  // void a() async {
  //   // WidgetsFlutterBinding.ensureInitialized();
  //   try {
  //     cameras = await availableCameras();
  //   } on CameraException catch (e) {
  //     print('Error: $e.code\nError Message: $e.message');
  //   }
  // }

}

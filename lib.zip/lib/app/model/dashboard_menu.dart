
import 'package:flutter/material.dart';


class DashboardMenu {
  final String? tittle, icon;
  final int? count;
  final Color? color;

  DashboardMenu(
      {required this.tittle,
      required this.icon,
      required this.count,
      required this.color});
}






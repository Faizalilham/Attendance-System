
import 'package:attendance_system/app/data/data_source/core/students_response.dart';
import 'package:attendance_system/app/theme/constant.dart';
import 'package:attendance_system/app/theme/extension.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';



class CardStudent extends StatelessWidget {
  Student student;
  CardStudent({Key? key, required this.student}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // double size = MediaQuery.of(context).size.width;
    return Container(
      padding: const EdgeInsets.all(defaultPadding / 2),
      decoration: const BoxDecoration(
          // image:  size < 340 ? const DecorationImage(image: AssetImage("assets/Icons/vector.png")) : const  DecorationImage(image: AssetImage("")),
          borderRadius: BorderRadius.all(Radius.circular(10))),
      child: InkWell(
          child: ExpansionTile(
            iconColor: primaryColor,
            collapsedIconColor: primaryColor,
            childrenPadding: const EdgeInsets.symmetric(vertical: 10,horizontal: 20),
        leading: CachedNetworkImage(
          imageUrl:
              student.images,
          imageBuilder: (context, imageProvider) => Container(
            width: 80.0,
            height: 80.0,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
            ),
          ),
          placeholder: (context, url) => Lottie.asset("assets/json/loading.json",height: 50,width:50),
          errorWidget: (context, url, error) => const Icon(Icons.error),
        ),
        title: Text(student.name, style: const TextStyle(fontSize: 16)),
        children: [
          Align(alignment:Alignment.centerLeft, child:Text(student.nim, style: const TextStyle(fontSize: 16))),
          Align(alignment:Alignment.centerLeft, child:Text(student.email, style: const TextStyle(fontSize: 16))),
           Align(
              alignment: Alignment.centerLeft,
              child: Text(student.address, style: const TextStyle(fontSize: 16))),
        ],
      )),
    ).addGlassmorphism();
  }
}
